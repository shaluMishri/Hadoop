# -*- coding: utf-8 -*-
"""
Created on Wed May 03 00:42:03 2017

@author: a8gg7
"""
#5/17 added this search case bool(re.search("runbook",root,re.IGNORECASE))==True 
#5/17 removed lending space from _cpy
# removed SS Omni Teammate Self Service Portal
# removed teller helped
# removed UTAH

import pandas as pd
import os
import re
from xlrd import open_workbook

df_paths=pd.read_excel("C:\\Users\\a8gg7\\Documents\\PSO RunBook Analysis\\DA Applications paths_cpy.xlsx")
print df_paths.columns.values
dn=pd.DataFrame(columns=["Job Name",'Sheet Name','Runbook name','document location','join path','App Name'])

for index, row in df_paths.iterrows():
    print index
 #   if index<180  :
  #      continue
   # else:
    #   pass
    doc_location=str(row["Documents Location"])
    app_name=str(row["Application Name"])
    print doc_location
    doc_loc_splitted=doc_location.split("\\")
    
    if os.path.isfile(doc_location):
        pass
    else:
        df = pd.DataFrame({'Job Name':["No jobs found"],'Sheet Name':["no sheet found"],'Runbook name':["no runbook found"],'document location':["location not found"],'join path':[doc_location],'App Name':[app_name]})
        dn=dn.append(df, ignore_index = True)
        
    
    if len(doc_loc_splitted)<12:
        print "incorrect location for " + row["Application Name"]
        continue;
        
    doc_loc_10='\\'.join(doc_loc_splitted[0:12])
    print doc_loc_10
    
    
    
    for root, dirs, files in os.walk(doc_loc_10,topdown=False):
       for name in files:
           doc_list= os.path.join(root, name)
           doc_list= '\\'.join(doc_list.split('\\')[-3:])
           
#       bool(re.search("TSS Omni",root,re.IGNORECASE))==False  and   if (bool (re.search("run",name,re.IGNORECASE)) or bool (re.search("ca7",name,re.IGNORECASE)) )  and bool(re.search("Archiv",root,re.IGNORECASE))==False and os.stat(os.path.join(root, name)).st_size != 0 and os.path.splitext(name)[1] in [ '.xls','.xlsx','.XLS'] and name.find("~") == -1  :
           if  bool(re.search("Metadata",name,re.IGNORECASE))==False and bool(re.search("Implementation_Backout",name,re.IGNORECASE))==False and  bool(re.search("mapping",name,re.IGNORECASE))==False and bool(re.search("itca",name,re.IGNORECASE))==False and bool(re.search("qa",name,re.IGNORECASE))==False and bool(re.search("dictionary",name,re.IGNORECASE))==False and bool(re.search("Archiv",root,re.IGNORECASE))==False and (bool(re.search("runbook",root,re.IGNORECASE))==True or bool(re.search("run book",root,re.IGNORECASE))==True) and os.path.isfile(os.path.join(root, name)) and bool(re.search("Table Data",root,re.IGNORECASE))==False and os.path.splitext(name)[1] in [ '.xls','.xlsx','.XLS'] and os.stat(os.path.join(root, name)).st_size != 0   and name.find("~") == -1  :
               run_book=os.path.join(root, name)
               run_book_name='\\'.join(run_book.split('\\')[-3:])
               print run_book
               insert_df=doc_location+","+doc_loc_10+","+run_book_name
               print insert_df
               
               book = open_workbook(run_book) 
               
               for sheet in book.sheets() :
                   sn= sheet.name
                   print sheet.name
                   jobs_found=0
                   for rowidx in range(sheet.nrows):
                        row = sheet.row(rowidx)
                        if jobs_found==1 or bool (re.search("QA",sheet.name,re.IGNORECASE)) or  bool (re.search("ITCA",sheet.name,re.IGNORECASE)):
                            break
                        else:
                            pass
                        for colidx, cell in enumerate(row):
                            if isinstance(cell.value, float) or isinstance(cell.value, int) :
                                continue
                            else:
                                cell_value=str(repr(cell.value.encode("utf8","ignore")))
                            if bool (re.search("jobname",cell_value,re.IGNORECASE)) or bool (re.search("job name",cell_value,re.IGNORECASE)) or bool (re.search("JCL Name",cell_value,re.IGNORECASE)) or  bool (re.search("CA7_Job_Name",cell_value,re.IGNORECASE)):
                                sn= sheet.name
                                ci= colidx
                                ri= rowidx
                                jobs_found=1
                                print "Jobs found"
                                break
                            else:
                                pass
#                                break
                            
                            
#                   print sn,ci,ri
                   if jobs_found == 1:
                       df=pd.read_excel(run_book,sheetname=sn,skiprows=ri,parse_cols=[ci],names=["Job Name"])
                       df.insert(1,'Sheet Name',sn)
                       df.insert(2,'Runbook name',run_book)
                       df.insert(3,'document location',doc_loc_10)
                       df.insert(4,'join path',doc_location)
                       df.insert(5,'App Name',app_name)
                       print df.shape                          
                       dn=dn.append(df, ignore_index = True)
                       print "size of appended book" 
                       print dn.shape
                       
                   else:
                       df = pd.DataFrame({'Job Name':["Runbook but no job here"],'Sheet Name':[sn],'Runbook name':[os.path.join(root, name)],'document location':[jobs_found],'join path':[doc_location],'App Name':[app_name]})
                       dn=dn.append(df, ignore_index = True)
                       
    #           writer = pd.ExcelWriter('C:\\Users\\a8gg7\\Documents\\PSO RunBook Analysis\\byApp\\Runbooks_Analysys_result_v0508'+app_name.replace('/','')+name+'.xls', engine='xlsxwriter')
    # Convert the dataframe to an XlsxWriter Excel object.
    #           dn.to_excel(writer, sheet_name='Sheet1')
    # Close the Pandas Excel writer and output the Excel file.
    #           writer.save()
           else :
               df = pd.DataFrame({'Job Name':["This is not runbook"],'Sheet Name':["This is not runbook"],'Runbook name':[os.path.join(root, name)],'document location':[doc_loc_10],'join path':[doc_location],'App Name':[app_name]})
               dn=dn.append(df, ignore_index = True)
                                         
                                       
                   
    print "-----size of appended book before loading into xls output---" 
    print "------------------------------------------------------------"
    print dn.shape
    writer = pd.ExcelWriter('C:\\Users\\a8gg7\\Documents\\PSO RunBook Analysis\\byApp\\Runbooks_Analysys_result_v0519_1.xls', engine='xlsxwriter')
    # Convert the dataframe to an XlsxWriter Excel object.
    dn.to_excel(writer, sheet_name='Sheet1')
    # Close the Pandas Excel writer and output the Excel file.
    writer.save()
   #exit(0)



#dn.to_excel('C:\\Users\\a8gg7\\Documents\\PSO RunBook Analysis\\Runbooks_Analysys_result_v5.xls')



    