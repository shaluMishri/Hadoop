
hadoop fs -rm -f /user/u4lwsfw0/Hive_tables.html
file1=/user/u4lwsfw0/count/000000_0
file2=/user/u4lwsfw0/Hive_tables.html
echo '<p align="center">Successfully sqooped table names and count</p><br><br>
<table border='1' align="center">
<tr  BGCOLOR="#90A6BD"><th> Database name</th><th>Table name</th><th>No of rows</th><th>TimeStamp</th></tr>'| hadoop fs -appendToFile -  $file2
hadoop fs -cat $file1  | while read line;
do
Dbname=`echo $line | cut  -f1  -d ' '`
name=`echo $line | cut  -f2  -d ' '`
count=`echo $line | cut  -f3  -d ' '`
sqooped=`echo $line | cut  -f4  -d ' '`
Time=`echo $line | cut  -f5  -d ' '`
echo "<tr><td>$Dbname</td><td>$name</td><td>$count</td><td>$sqooped $Time</td></tr>"|hadoop fs -appendToFile -  $file2
done 
echo "</table>"|hadoop fs -appendToFile -  $file2