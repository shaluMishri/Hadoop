#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 10/26/2017
Created Version - 1.0

Script Parameters:

$1       - Archive enabled? ( 1 or 0)
$2       - Archive directory 
$3       - Sqoop target directory 

Description: 

This script moves current sqoop'd data to archive directory only if archive flag is enabled.  

COMMENT


echoerr() { echo "$@" 1>&2; }

if [ $1 -eq 1 ] ; then hadoop fs -mkdir -p $2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_1=Failed to create archive directory"; exit 1; else echo "msg_1=Archive directory created"; fi

hadoop fs -cp $3 $2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_2=Failed to archive data"; exit 1; else echo "msg_2=Data archived"; fi 

else echo "msg=Archive disabled, so no operation performed"; fi
