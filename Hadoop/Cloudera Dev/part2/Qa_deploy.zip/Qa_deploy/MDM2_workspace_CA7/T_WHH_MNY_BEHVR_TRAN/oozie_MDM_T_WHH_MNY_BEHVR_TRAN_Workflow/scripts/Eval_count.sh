#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 10/26/2017
Created Version - 1.0

Script Parameters:

$1       - Source Database table Name
$2       - HDFS count Directory
$3       - load_max_months_limit_enabled? (1/0)
$4       - load_max_months_limit
$5       - hive_load_date

Description: 

This script generates sqoop count for a specific day load.

COMMENT


echoerr() { echo "$@" 1>&2; }

mdm_wk_perd_key=$(hadoop fs -text /user/uzlweir1/max_mdm_key_hive_t_whh_mny_behvr_tran/* | grep -Po "\d+" | tail -1)

start_wk_perd_key=$(expr $mdm_wk_perd_key + 1)

if [ $3 -eq 1 ] ; then end_wk_perd_key=$(expr $mdm_wk_perd_key + $4)

else end_wk_perd_key=$(expr $mdm_wk_perd_key + 12); fi

query_criteria="mdm_wk_perd_key between $start_wk_perd_key and $end_wk_perd_key"

echo "query_criteria"=$query_criteria

echo "mdm_wk_perd_key="$mdm_wk_perd_key

eval_out=`sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/uzlweir1/mdm.password.jceks --connect jdbc:db2://NC006QADFCE.suntrust.com:60000/DQA01MDM --username "uzlweir1" -password-alias mdm.password.alias --query "select count(*) from $1 where $query_criteria"` || { echoerr 'Sqoop Eval command Failed' ; exit 1; }

count=`echo $eval_out | grep -Po "\d+" | tail -1`

echo $count > /home/uzlweir1/count_sqoop5.txt

hadoop fs -put /home/uzlweir1/count_sqoop5.txt $2/sqoop/$5/count_sqoop.txt>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_4=Failed to save the sqoop count"; exit 1; else echo "msg_4=Count saved for the month"; fi
