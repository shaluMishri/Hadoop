#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - Source Database table Name
$2       - HDFS count Directory
$3       - load_max_months_limit_enabled? (1/0)
$4       - load_max_months_limit
$5       - hive_load_date

Description: 

This script generates sqoop count for a specific day load.

COMMENT


echoerr() { echo "$@" 1>&2; }

mdm_mth_perd_key=$(hadoop fs -text /user/uzlweir1/max_mdm_key_hive_t_acct_dim/* | grep -Po "\d+" | tail -1)

start_mth_perd_key=$(expr $mdm_mth_perd_key + 1)

if [ $3 -eq 1 ] ; then end_mth_perd_key=$(expr $mdm_mth_perd_key + $4)

else end_mth_perd_key=$(expr $mdm_mth_perd_key + 12); fi

query_criteria="mdm_mth_perd_key between $start_mth_perd_key and $end_mth_perd_key"

echo "query_criteria"=$query_criteria

echo "mdm_mth_perd_key="$mdm_mth_perd_key

eval_out=`sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/uzlweir1/mdm.password.jceks --connect jdbc:db2://NC006QADFCE.suntrust.com:60000/DQA01MDM --username "uzlweir1" -password-alias mdm.password.alias --query "select count(*) from $1 where $query_criteria"` || { echoerr 'Sqoop Eval command Failed' ; exit 1; }

count=`echo $eval_out | grep -Po "\d+" | tail -1`

echo $count > /home/uzlweir1/count_sqoop2.txt

hadoop fs -put /home/uzlweir1/count_sqoop2.txt $2/sqoop/$5/count_sqoop.txt>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_4=Failed to save the sqoop count"; exit 1; else echo "msg_4=Count saved for the month"; fi
