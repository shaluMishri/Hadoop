#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1        - HDFS count Directory 
$2        - hive_load_date

Description: 

This script validates hive count against sqoop count for a specific day load and echo the counts and validation status.

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -cp -f /user/uzlweir1/count_hive3/* $1/hive/$2/count_hive.txt>/dev/null

if [ $? -ne 0 ]; then echoerr "msg_2=Failed to store Hive count"; exit 1; else echo "msg_2=Hive count saved"; fi

hive_count=`hadoop fs -text $1/hive/$2/count_hive.txt | grep -Po "\d+" | tail -1`

sqoop_count=`hadoop fs -text $1/sqoop/$2/count_sqoop.txt | grep -Po "\d+" | tail -1`

validation="Fail"

if [ $hive_count == $sqoop_count ] ; then validation="Success"; fi

echo "HiveCount="$hive_count

echo "SqoopCount="$sqoop_count

echo "Validation="$validation
