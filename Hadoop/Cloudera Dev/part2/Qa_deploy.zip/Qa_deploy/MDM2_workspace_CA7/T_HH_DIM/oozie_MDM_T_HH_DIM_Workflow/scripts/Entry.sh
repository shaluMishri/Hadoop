#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS count Directory
$2       - hive_load_date

Description: 

This script checks if data is already loaded for the same date. If yes, returned code from script is '1' (failure of data loading).

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/sqoop/$2>/dev/null

if [ $? -ne 0 ]; then echoerr "msg_3=Failed to create sqoop count directory for the month"; exit 1; 

else echo "msg_3=Sqoop Count directory created"; fi

hadoop fs -mkdir -p $1/hive/$2>/dev/null

if [ $? -ne 0 ]; then echoerr "msg_4=Failed to create hive count directory for the month"; exit 1; 

else echo "msg_4=Hive Count directory created"; fi

hadoop fs -test -e $1/sqoop/$2/count_sqoop.txt>/dev/null

if [ $? -eq 0 ]; then echoerr "Job already loaded for this day..Failing Job now"; exit 1; fi
