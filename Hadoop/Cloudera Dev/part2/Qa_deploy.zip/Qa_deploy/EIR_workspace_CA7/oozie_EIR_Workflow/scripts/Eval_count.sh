#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1         - Source Database table Name
$2         - HDFS count Directory
$3         - load_max_days_limit_enabled? (1/0)
$4         - load_max_days_limit
$5         - hive_load_date

Description: 

This script generates sqoop count for a specific day load.

COMMENT


echoerr() { echo "$@" 1>&2; }

max_bi_creat_ts=$(hadoop fs -text /user/uzlweir1/max_bi_creat_ts_eir_hive/* | grep -Po "\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(.\d{1,6})?" | tail -1)

tmp_date=$(date -d "$max_bi_creat_ts")

if [ $3 -eq 1 ] ; then end_date=$(date +%Y-%m-%d -d "$tmp_date + $4 day"); else end_date=$(date +%Y-%m-%d -d "$tmp_date + 365 day"); fi

query_criteria="bi_creat_ts between trunc_timestamp('$max_bi_creat_ts','SS') + 1 second and '$end_date' and src_chnl_cd NOT IN ('CME', 'CMU')"

echo "query_criteria"=$query_criteria

echo "max_bi_creat_ts="$max_bi_creat_ts

eval_out=`sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/uzlweir1/eir.pdoa.password.jceks --connect jdbc:db2://bidb-qa.suntrust.com:50000/dqa01cdw --username "uzlweir1" -password-alias eir.password.alias --query "select count(*) from $1 where $query_criteria with ur"` || { echoerr 'Sqoop Eval command Failed' ; exit 1; }

count=`echo $eval_out | grep -Po "\d+" | tail -1`

echo $count > /home/uzlweir1/count_sqoop.txt

hadoop fs -put /home/uzlweir1/count_sqoop.txt $2/sqoop/$5/count_sqoop.txt>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_1=Failed to save the sqoop count"; exit 1; else echo "msg_1=Sqoop count saved for the month"; fi
