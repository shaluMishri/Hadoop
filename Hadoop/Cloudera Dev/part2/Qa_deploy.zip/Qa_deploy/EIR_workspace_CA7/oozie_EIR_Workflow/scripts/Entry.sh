#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS count Directory
$2       - hive_load_date

Description: 

This script checks if data is already loaded for the same date. If yes, returned code from script is '1' (failure of data loading).

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/sqoop/$2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_1=Failed to create sqoop count directory"; exit 1; else echo "msg_1=Sqoop count directory created"; fi

hadoop fs -mkdir -p $1/hive/$2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_2=Failed to create hive count directory"; exit 1; else echo "msg_2=Hive count directory created"; fi

hadoop fs -test -e $1/sqoop/$2/count_sqoop.txt>/dev/null 

if [ $? -eq 0 ] ; then echoerr "Load Job For Load Day = $2, Executed already earlier..Failing Job now"; exit 1; fi
