#!/bin/sh

oozie job -oozie http://qbda1node04.suntrust.com:11000/oozie -config oozie/job.properties -run -verbose
