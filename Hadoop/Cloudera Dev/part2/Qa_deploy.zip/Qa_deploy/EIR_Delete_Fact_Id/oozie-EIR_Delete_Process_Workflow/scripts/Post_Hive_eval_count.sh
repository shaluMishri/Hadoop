#!/bin/sh

<<COMMENT
Created by - Nikunj Patel
Created date - 05/02/2017
Created Version - 1.0

Script Parameters:

$1   - HDFS Data Directory

Description: 

This script saves delete_fact_id_count, pre_delete_full_count, post_delete_full_count from temp location to count directory

COMMENT


hadoop fs -mkdir -p $1/Count/hive>/dev/null

hadoop fs -rm $1/Count/hive/post_delete_full_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/delete_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/delete_fact_id_count_hive.txt>/dev/null
hadoop fs -rm $1/Count/hive/pre_delete_full_count_hive.txt>/dev/null

hadoop fs -cp /tmp/delete_count_hive/* $1/Count/hive/delete_count_hive.txt>/dev/null
hadoop fs -cp /tmp/delete_fact_id_count_hive/* $1/Count/hive/delete_fact_id_count_hive.txt>/dev/null
hadoop fs -cp /tmp/pre_delete_full_count_hive/* $1/Count/hive/pre_delete_full_count_hive.txt>/dev/null
hadoop fs -cp /tmp/post_delete_full_count_hive/* $1/Count/hive/post_delete_full_count_hive.txt>/dev/null

DeleteRecordCount=`hadoop fs -text $1/Count/hive/delete_count_hive.txt | grep -Po "\d+" | tail -1`
DeleteFact_IdCount=`hadoop fs -text $1/Count/hive/delete_fact_id_count_hive.txt | grep -Po "\d+" | tail -1`
Pre_DeleteHiveCount=`hadoop fs -text $1/Count/hive/pre_delete_full_count_hive.txt | grep -Po "\d+" | tail -1`
Post_DeleteHiveCount=`hadoop fs -text $1/Count/hive/post_delete_full_count_hive.txt | grep -Po "\d+" | tail -1`

echo "DeleteFact_IdCount="$DeleteFact_IdCount
echo "DeleteRecordCount="$DeleteRecordCount
echo "Pre_DeleteHiveCount="$Pre_DeleteHiveCount
echo "Post_DeleteHiveCount="$Post_DeleteHiveCount
