#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS Count Directory
$2       - HDFS Data Load Directory
$3       - Unix Data Load Directory
$4       - hive_load_date

Description: 

This script checks whether the data is already loaded for same Month. If yes, it will first take the backup of the count folder.

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/sqoop/$4>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_3=Failed to create sqoop count directory"; exit 1; else echo "msg_3=Sqoop count directory created"; fi

hadoop fs -test -e $1/sqoop/$4/count_sas.txt>/dev/null 

if [ $? -eq 0 ] ; then echoerr "Load Job For Load Day = $4, Executed already earlier..Failing Job now"; exit 1; fi

file_check=$(find $3 -type f | wc -l)

echo "Checking data availability at unix location: " $3

echo "File_check"=$file_check

if [ "$file_check"  == "0" ] ; then
     file_availability="no"
     echoerr "msg_1=Sas data is not available for current load ...failing workflow now"
     echo "file_availability="$file_availability
     exit 1;
else 
     file_availability="yes"
     echo "file_availability="$file_availability
     hadoop fs -put -f $3/* $2
fi
