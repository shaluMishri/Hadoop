#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54, uinp18
Created date - 09/08/2017
Created Version - 1.0

Script Parameters:

$1        - HDFS Count Directory 
$2        - hive_load_date

Description: 

This script saves the count for current month in count directory.

COMMENT


echoerr() { echo "$@" 1>&2; }

Status="Failed"

hadoop fs -cp /user/uzlweir1/count_hive_sas_modeling/* $1/sqoop/$2/count_sas.txt>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_2=Failed to store Hive count"; exit 1; else echo "msg_2=Hive count saved"; Status="Success"; fi

hive_count=`hadoop fs -text $1/sqoop/$2/count_sas.txt | grep -Po "\d+" | tail -1`

echo "HiveCount="$hive_count

echo "Status="$Status
