#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 11/23/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS Count Directory
$2       - HDFS Data Load Directory
$3       - Unix Data Load Directory
$4       - hive_load_date

Description: 

This script checks whether the data is already loaded for same week. If yes, it will first take the backup of the count folder.

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/hive/$4>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_3=Failed to create hive count directory"; exit 1; else echo "msg_3=Hive count directory created"; fi

hadoop fs -test -e $1/hive/$4/count_sas_monetary.txt>/dev/null 

if [ $? -eq 0 ] ; then echoerr "Load Job For Load Day = $4, Executed already earlier... Failing Job now"; exit 1; fi

file_check=$(find $3 -type f | wc -l)

echo "Checking data availability at unix location: " $3

if [ "$file_check" == "0" ] ; then echoerr "msg_1=Sas monetary data is not available for current load..failing workflow now"; exit 1;

else echo "file available"; hadoop fs -put -f $3/* $2; fi
