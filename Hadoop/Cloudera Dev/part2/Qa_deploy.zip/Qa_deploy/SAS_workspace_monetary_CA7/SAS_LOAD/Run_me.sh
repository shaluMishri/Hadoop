#!/bin/sh

job_properties="/zone2/ae/marketing/eir/SAS_workspace_monetary_CA7/SAS_LOAD/oozie/job.properties"
job_template="/zone2/ae/marketing/eir/SAS_workspace_monetary_CA7/SAS_LOAD/oozie/job_template.properties"
cat ${job_properties} > ${job_template}
echo "" >> ${job_template}
echo "hive_load_date="$(date +'%Y-%m-%d') >> ${job_template}

oozie_url="http://qbda1node04.suntrust.com:11000/oozie"
current_time="$(date)"
echo " ------------------ Initializing load of SAS Monetary Table ------------------ "
echo "current_time="$current_time

oozie_workflow_id=$(oozie job -oozie ${oozie_url} -config ${job_template} -run | sed -n 's/job: \(.*\)/\1/p'); 

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep RUNNING > /dev/null )
do
  sleep 5
  echo "running"
done

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep FAILED > /dev/null )
do
  echo "Failed with exit 42"
  exit 42
done

while ( oozie job -oozie ${oozie_url} -info ${oozie_workflow_id} | grep KILLED > /dev/null )
do
  echo "Failed with exit 42"
  exit 42
done
