#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 12/06/2017
Created Version - 1.0

Script Parameters:

$1         - Source Database table Name
$2         - HDFS count Directory
$3         - hive_load_date
$4         - start_dt
$5         - end_dt

Description: 

This script generates sqoop count for a specific day load.

COMMENT


echoerr() { echo "$@" 1>&2; }

query_criteria="calndr_dt between '$4' and '$5' and src_chnl_cd NOT IN ('CME', 'CMU')"

echo "query_criteria"=$query_criteria

eval_out=`sqoop eval -Dhadoop.security.credential.provider.path=jceks://hdfs/user/uzlweir1/eir.pdoa.password.jceks --connect jdbc:db2://bidb-qa.suntrust.com:50000/dqa01cdw --username "uzlweir1" -password-alias eir.password.alias --query "select count(*) from $1 where $query_criteria with ur"` || { echoerr 'Sqoop Eval command Failed' ; exit 1; }

count=`echo $eval_out | grep -Po "\d+" | tail -1`

echo $count > /home/uzlweir1/count_sqoop.txt

hadoop fs -put -f /home/uzlweir1/count_sqoop.txt $2/sqoop/$3/count_sqoop.txt>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_1=Failed to save the sqoop count"; exit 1; else echo "msg_1=Sqoop count saved for the month"; fi
