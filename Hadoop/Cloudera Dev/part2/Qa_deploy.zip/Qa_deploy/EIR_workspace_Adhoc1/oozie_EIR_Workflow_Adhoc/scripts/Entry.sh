#!/bin/sh

<<COMMENT

Created by - INFOSYS - uink54
Created date - 12/06/2017
Created Version - 1.0

Script Parameters:

$1       - HDFS count Directory
$2       - hive_load_date
$3       - start_dt
$4       - end_dt

Description: 

This script checks if data is already loaded for the same date. If yes, returned code from script is '1' (failure of data loading).

COMMENT


echoerr() { echo "$@" 1>&2; }

hadoop fs -mkdir -p $1/sqoop/$2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_1=Failed to create sqoop count directory"; exit 1; else echo "msg_1=Sqoop count directory created"; fi

hadoop fs -mkdir -p $1/hive/$2>/dev/null

if [ $? -ne 0 ] ; then echoerr "msg_2=Failed to create hive count directory"; exit 1; else echo "msg_2=Hive count directory created"; fi

echo "start_dt="$3

echo "end_dt="$4
