#!/bin/sh

<<COMMENT

Created by - INFOSYS - a8gg7,uism172
Created date - 11/11/2017
Created Version - 1.0

Script Parameters: Provide Counter and Date(not mandatory)
 $1 : Counter
 $2 : Date

Assumption: No table present with Staging table Name,final table must be present.
Description: This script import data from source to Zone 2 Hive partitioned table to in parquet format.

COMMENT

COUNTER_VAR=$1
START_DATE=$2
FILEPATH="/home/uism172/FDR_Sqoop/table_details.csv"

hive2_server_principal_url="jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM"
hadoop_Security="-Dhadoop.security.credential.provider.path=jceks://hdfs/user/a8gg7/cme.password.jceks"
hive_dyn_partn_property="hive.exec.dynamic.partition.mode=nonstrict,hive.exec.dynamic.partition=true"

email_ids="Shalu.Mishra@SunTrust.com Ganesh.Gurusiddaiah@SunTrust.com"
logs="/home/uism172/FDR_Sqoop/Logs/"

counter=1
msg_mail=" "

#Read table_details.csv 
while read line;
do 
       
        driver="$(echo "$line"|cut -d, -f1)";
	 connection_String="$(echo "$line"|cut -d, -f2)";
	 username="$(echo "$line" |cut -d, -f3)";
	 password_Alias="$(echo "$line" |cut -d, -f4)"
	 mapper="$(echo "$line" |cut -d, -f5)"  
	 src_Schema_Name="$(echo "$line" |cut -d, -f6)"  
	 src_Table_Name="$(echo "$line"|cut -d, -f7)"   
        tgt_Directory="$(echo "$line"|cut -d, -f8)"    
	 tgt_Schema_Name="$(echo "$line"|cut -d, -f9)"		
        tgt_Table_Name="$(echo "$line"|cut -d, -f10)"   
	 key="$(echo "$line"|cut -d, -f11)"   
        key_datatype="$(echo "$line"|cut -d, -f12)"   
        fetch_size="$(echo "$line"|cut -d, -f13)"
         

done < ${FILEPATH}

while [ "${counter}" -lt "${COUNTER_VAR}" ] ; do
staging_Table_Name=${src_Table_Name}_STAGING_${counter}

#Max Partition Date available in Target Table and Increment date field to sqoop next date data

if [ "${counter}" -eq 1 -a  $# -eq 2 ]; then
       max_Date_Partition=${START_DATE}

elif [ "${counter}" -eq 1 -a  $# -eq 1 ]; then
       beeline -u "${hive2_server_principal_url}" -n ${username} -e "select max(${key}) from ${tgt_Table_Name}">"./max_partition.csv"
       max_Date_Partition=$(awk '{ print $2 }' max_partition.csv|tail -2 |head -1)
    
else   
if [ "${counter}" -gt 1 ]; then
       next_Date=$(date -d "${max_Date_Partition} 1 days" +%Y-%m-%d)
       max_Date_Partition=${next_Date}
fi
fi


#Sqoop from source to Staging Text Table

       value_where_clause=" ${key}='${max_Date_Partition}' "
       value_map_column=${key}\=${key_datatype}
       sqoop import "${hadoop_Security}" --driver ${driver} --connect ${connection_String} --username ${username} -password-alias ${password_Alias} -m${mapper} -table ${src_Schema_Name}.${src_Table_Name} --where "${value_where_clause}" --target-dir ${tgt_Directory} --hive-table ${staging_Table_Name} --as-textfile --create-hive-table --map-column-hive ${value_map_column} --hive-database ${tgt_Schema_Name} --hive-import --split-by ${key} --fetch-size ${fetch_size} --delete-target-dir &>>"./logs.txt"
       if [ $? -ne 0 ] ; then msg_mail+=" \n     FAILED TO SQOOP DATA INTO  '${staging_Table_Name}'     FOR DATE    '${max_Date_Partition}'             \n "; else  msg_mail+="   ${counter} SUCCESSFULLY IMPORTED  '${staging_Table_Name}'  FOR DATE  '${max_Date_Partition}'            \n " ; fi

	
#Compare Source and target Counts and hive insert command to append to final table

       query_criteria=" ${key}='${max_Date_Partition}' "
      	sqoop eval "${hadoop_Security}" --driver ${driver} --connect ${connection_String} --username ${username} -password-alias ${password_Alias} --query "select count(*) from ${src_Schema_Name}.${src_Table_Name} where ${query_criteria} " >"${logs}source_table_Count.txt"
       beeline -u "${hive2_server_principal_url}" -n ${username} -e "select count(*) from ${tgt_Schema_Name}.${staging_Table_Name}" >"${logs}staging_table_Count.txt" 
       
       source_Count=$(awk '{print $2}' ${logs}source_table_Count.txt |tail -2|head -1)	
       target_Count=$(awk '{print $2}' ${logs}staging_table_Count.txt |tail -2|head -1)

       if [ "${source_Count}" -eq "${target_Count}" ];then
	     echo "${source_Count},${target_Count}" >> ${logs}count_sqoop.txt

         if [ "${source_Count}" -ne 0 ];then
            beeline -u "${hive2_server_principal_url}" -n ${username} --hiveconf "${hive_dyn_partn_property}" -e "insert into table ${tgt_Schema_Name}.${tgt_Table_Name} partition (${key}) select RDT_MONETARY_DCX_SEQ_NBR,RDT_REC_CODE_KEY,RDT_REC_TYPE_CONTROL,RDT_NO_POST_REASON,RDT_SC_1,RDT_SC_2,RDT_SC_3,RDT_SC_4,RDT_SC_5,RDT_SC_6,RDT_SC_7,RDT_SC_8,RDT_CHD_SYSTEM_NO,RDT_CHD_PRIN_BANK,RDT_CHD_AGENT_BANK ,RDT_CHD_ACCOUNT_NUMBER,RDT_TRANSACTION_CODE,RDT_MRCH_SYSTEM_NO,RDT_MRCH_PRIN_BANK,RDT_MRCH_AGENT_NO,RDT_MRCH_ACCOUNT_NUMBER,RDT_CHD_EXT_STATUS,RDT_CHD_INT_STATUS,RDT_TANI,RDT_TRANSFER_FLAG ,RDT_ITEM_ASSES_CODE_NUM,RDT_MRCH_SIC_CODE,RDT_TRANSACTION_DATE,RDT_DCX_BATCH_TYPE,RDT_DCX_JULIAN_DATE,RDT_DCX_TYPE,RDT_DCX_SYS_4,RDT_DCX_SYS_2,RDT_DCX_DATE ,RDT_DCX_2 ,RDT_DCX_LAST_6,RDT_DCX_ADJ_SALE_FEE_AM ,FILLER_2,RDT_DCX_MON_TRAN_JOURNAL_AMT,RDT_DCX_AUDIT_TRAIL_DATE ,RDT_DCX_PRIN_TOTAL,RDT_DCX_PRIN_CASH,RDT_DCX_PRIN_MRCH,RDT_DCX_STMT_FIN_CHG_OFF,RDT_DCX_MTJ_FIN_CHG_OFF,RDT_DCX_BAL_TRAN_DUAL_FLAG,RDT_DCX_PRIN_MISC_CHGS,RDT_DCX_CR_LIFE_CHG_OFF,RDT_DCX_ACCRUED_CASHINT,RDT_DCX_ACCRUED_MRCHINT,RDT_DCX_BALANCE_CHG_OFF,RDT_DCX_OLD_OPEN_BALANCE,RDT_DCX_ACCRUED_CRDINT,FILLER_3,RDT_DCX_ADDL,FILLER_3A,FILLER_4,cast(${key} as date) as ${key} from  ${tgt_Schema_Name}.${staging_Table_Name}" &>>"./logs.txt"
            if [ $? -ne 0 ] ; then msg_mail+=" \n             FAILED TO LOAD DATA FOR DATE  '${max_Date_Partition}'   \n ------------------------------------------------------------------------------ \n " ; else  msg_mail+=" \n   SUCCESSFULLY LOADED DATA INTO  '${tgt_Table_Name}'  FOR DATE  '${max_Date_Partition}'          \n ------------------------------------------------------------------------------ \n  "; fi   
 
            #drop staging table
            #beeline -u "jdbc:hive2://qbda1node04:10000/eir_sas_shared;principal=hive/qbda1node04.suntrust.com@CORP.SUNTRUST.COM" -n uism172 -e "drop table ${tgt_Schema_Name}.${staging_Table_Name}" >>"${logs}logs.txt"
         fi

	else

	     echo -e "$msg_mail .Please check logs" | mail -s "Msg:Failed Import ${tgt_Table_Name} " ${email_ids}
       
       fi
	   
((counter++))
done

#Sending mail and exit
echo -e "$msg_mail" | mail -s "Msg:Successful Import ${tgt_Table_Name}" ${email_ids}
	