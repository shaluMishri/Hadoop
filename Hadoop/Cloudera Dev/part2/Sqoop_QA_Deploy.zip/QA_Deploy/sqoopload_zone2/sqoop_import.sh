#!/bin/bash
for b in *.csv; do

    file=$b

done

if [ -f $file ];
then
line_count=$(wc -l <$file)
n=$line_count
   source=()
   partiton_key=()
   mappers=()
    hivedb=()
   hivetable=()
  username=()
  password=()
 connection=()
 passwordpath=()
 column=()
 where=()
target=()

rm -f sqoopload_zone2_workflow.xml
rm -f hive2.hql
hadoop fs -rm -f  /user/ugsm388/sqoopload_zone_workflow/sqoopload_zone2_workflow.xml
hadoop fs -rm -f /user/ugsm388/sqoopload_zone2_workflow/hive2.hql
echo "<workflow-app name=\"sqoop_Workflow\" xmlns=\"uri:oozie:workflow:0.5\" >
	<global>
		<configuration>
          <property>
               <name>hive</name>
               <value>>/user/ugsm388/sqoopload_zone_workflow/hive-site.xml</value>
            </property>

            <property>
               <name>oozie_url</name>
               <value>\${oozie_url}</value>
            </property>    
            <property>
               <name>oozie.use.system.libpath</name>
               <value>True</value>
            </property>
            
            <property>
               <name>email_ids</name>
               <value>\${email_ids}</value>
            </property>
            <property>
               <name>queueName</name>
               <value>\${queueName}</value>
            </property>
            <property>
               <name>load_max_days_limit_enabled</name>
               <value>1</value>
            </property>
            <property>
               <name>load_max_days_limit</name>
               <value>4</value>
            </property>
            <property>
               <name>debug_url</name>
               <value>\${debug_url}</value>
            </property>
			<property>
				<name>oozie.launcher.mapreduce.job.queuename</name>
				<value>\${queueName}</value>
			</property>
			<property>
				<name>mapreduce.job.queuename</name>
				<value>\${queueName}</value>
			</property>  
                        <property>
                                <name>mapred.child.java.opts</name>
                                <value>-server -Xmx1024M -Djava.net.preferIPv4Stack=true</value>
                        </property>
                        <property>
                                <name>oozie.launcher.mapreduce.map.memory.mb</name>
                                <value>16384</value>
                        </property>
                        <property>
                                <name>oozie.launcher.mapreduce.map.java.opts</name>
                                <value>-Xmx15g</value>
                        </property>
                        <property>
                                <name>oozie.launcher.yarn.app.mapreduce.am.resource.mb</name>
                                <value>768</value>
                        </property>
                        <property>
                                <name>oozie.launcher.yarn.app.mapreduce.am.command-opts</name>
                                <value>-Xmx512m</value>
                        </property>
                        <property>
                                <name>mapreduce.map.java.opts</name>
                                <value>-Xmx10240m -Ddb2.jcc.charsetDecoderEncoder=3</value>
                        </property>
                        <property>
                                <name>oozie.launcher.mapred.map.child.env</name>
                                <value>HADOOP_CREDSTORE_PASSWORD=none</value>
                        </property>
                        <property>
                                <name>oozie.launcher.mapreduce.map.maxattempts</name>
                                <value>1</value>
                        </property>
                        <property>
                                <name>mapreduce.map.maxattempts</name>
                                <value>1</value>
                        </property>
                
			<property>
				<name>mapreduce.map.memory.mb</name>
				<value>9216</value>
			</property>
			<property>
				<name>mapreduce.reduce.java.opts</name>
				<value>-Xmx8192m</value>
			</property>
			<property>
               			<name>hive</name>
               			<value>>/user/ugsm388/sqoopload_zone_workflow/hive-site.xml</value>
            		</property>
		</configuration>
	</global>
	<credentials>
		<credential name=\"hcat\" type=\"hcat\">
			<property>
				<name>hcat.metastore.uri</name>
				<value>\${hcat_metastore_uri}</value>
			</property>
			<property>
				<name>hcat.metastore.principal</name>
				<value>\${hcat_metastore_principal}</value>
			</property>
		</credential>
		<credential name=\"hive2\" type=\"hive2\">
			<property>
				<name>hive2.jdbc.url</name>
				<value>\${hive2_jdbc_url}</value>
			</property>
			<property>
				<name>hive2.server.principal</name>
				<value>\${hive2_server_principal}</value>
			</property>
		</credential>
	</credentials>
	<start to=\"email-start\"/>
        <kill name=\"kill\">
               <message>Action failed, error message[\${wf:errorMessage(wf:lastErrorNode())}]</message>

        </kill>
	<action name=\"email-start\">
		<email xmlns=\"uri:oozie:email-action:0.2\">
		 	<to>\${email_ids}</to>
			<subject>Started | \${wf:name()} - \${wf:id()}</subject>
			<body> 
workflow Name : \${wf:name()} 
workflow Id : \${wf:id()} 

Status : Started for further details check at below location : \${debug_url}/\${wf:id()} 

or 

Run below command from commandline: 
oozie job -oozie \${oozie_url} -info \${wf:id()}</body>
			<content_type>text/plain</content_type>
		</email>
		<ok to=\"fork-node\"/>
		<error to=\"kill\"/>
	</action>
 <fork name=\"fork-node\"> ">> sqoopload_zone2_workflow.xml

z=1
while read line ;
do
    test $z -eq 1 && ((z=z+1)) && continue 
    source1=`echo $line | cut  -f1  -d ','`
    partiton_key1=`echo $line | cut  -f2  -d ','` 
    mappers1=`echo $line | cut  -f3  -d ','`
    hivedb1=`echo $line | cut  -f4  -d ','`
    hivetable1=`echo $line | cut  -f5  -d ','`
    username1=`echo $line | cut  -f6  -d ','`
    password1=`echo $line | cut  -f7  -d ','`
    connection1=`echo $line | cut  -f8  -d ','`
     passwordpath1=`echo $line | cut  -f9  -d ','`
    column1=`echo $line | cut  -f10  -d ','`
   where1=`echo $line | cut  -f11  -d ','`
   target1=`echo $line | cut  -f12  -d ','`
    source+=("$source1")
    partiton_key+=("$partiton_key1")
    mappers+=("$mappers1")
    hivedb+=("$hivedb1")
    hivetable+=("$hivetable1")
    username+=("$username1")
    password+=("$password1")
    connection+=("$connection1")
     passwordpath+=("$passwordpath1")
     column+=("$column1")
   where+=("$where1")
   target+=("$target1")
done < $file
i=0
p=$1
while [ $i -le $p ]
do 
Hivedb=${hivedb[$i]}

echo "<path start=\"${hivetable[$i]}\"/>" >>sqoopload_zone2_workflow.xml
((i++))
done

echo "</fork>">>sqoopload_zone2_workflow.xml
j=0

echo "use $Hivedb;
drop table sqoop PURGE;
create table IF NOT EXISTS  Hive_Audit(Dbname String,name string,count Int,sqoopedTime Timestamp); 
create table IF NOT EXISTS  sqoop(Dbname String,name string,count Int,sqoopedTime Timestamp);">>hive2.hql
while [ $j -le $[$n-2] ];
do
source=${source[$j]}
source=`echo $source | sed 's/;/,/g'`
value=${where[$j]}
value1=${where[$j]}
value=`echo $value | sed 's/;/,/g'`
value1=`echo $value | sed 's/;/,/g'`
if [[ $value == 'NULL' ]]; then
value=" "
else
value+=" "
value+="and"
fi
if [[ ${column[$j]} == *ALL ]]|| [ ${column[$j]} == "ALL" ]
then
x=${column[$j]}

x=`echo $x | sed 's/ALL/\*/g'`
else
x=${column[$j]}

x=`echo $x | sed 's/;/,/'`
fi
if [[ $value1 == 'NULL' ]]; then
echo "<action name=\"${hivetable[$j]}\" cred=\"hcat,hive2\">
	 <sqoop xmlns=\"uri:oozie:sqoop-action:0.2\">
		<job-tracker>\${jobTracker}</job-tracker>
		<name-node>\${nameNode}</name-node>
		<job-xml>>/user/ugsm388/sqoopload_zone_workflow/hive-site.xml</job-xml>
		<arg>import</arg>
        	<arg>-Dhadoop.security.credential.provider.path=${passwordpath[$j]}</arg>
        	<arg>--connect</arg>
        	<arg>${connection[$j]}</arg>
        	<arg>--username</arg>
        	<arg>${username[$j]}</arg>
		<arg>-password-alias</arg>
		<arg>${password[$j]}</arg>
		<arg>-m</arg>
		<arg>1</arg>
		<arg>--direct</arg>
		<arg>--fetch-size</arg>
		<arg>5000</arg>
		<arg>--query</arg>
           <arg>\"select $x  from $source where $value   	\$CONDITIONS\"</arg>
		<arg>--delete-target-dir</arg>
		<arg>--target-dir</arg>
		<arg>${target[$j]}</arg>
		<arg>--as-textfile</arg>
		<arg>--relaxed-isolation</arg>
		<arg>--hive-import</arg>
                <arg>--hive-delims-replacement</arg>
		<arg>\"\\\N\"</arg>
		<arg>--hive-overwrite</arg>
		<arg>--hive-table</arg>
		<arg>temp_${hivetable[$j]}</arg>
		<arg>--as-textfile</arg>
		<arg>--create-hive-table</arg>
		<arg>--hive-database</arg>
		<arg>${hivedb[$j]}</arg>
		<arg>--compression-codec</arg>
		<arg>org.apache.hadoop.io.compress.SnappyCodec</arg>


	</sqoop>">>sqoopload_zone2_workflow.xml


else
	echo "<action name=\"${hivetable[$j]}\" cred=\"hcat,hive2\">
         <sqoop xmlns=\"uri:oozie:sqoop-action:0.2\">
                <job-tracker>\${jobTracker}</job-tracker>
                <name-node>\${nameNode}</name-node>
                <job-xml>>/user/ugsm388/sqoopload_zone_workflow/hive-site.xml</job-xml>
                <arg>import</arg>
                <arg>-Dhadoop.security.credential.provider.path=${passwordpath[$j]}</arg>
                <arg>--connect</arg>
                <arg>${connection[$j]}</arg>
                <arg>--username</arg>
                <arg>${username[$j]}</arg>
                <arg>-password-alias</arg>
                <arg>${password[$j]}</arg>
                <arg>-m${mappers[$j]}</arg>
                <arg>--split-by</arg>
                <arg>${partiton_key[$j]}</arg>
                <arg>--query</arg>
                <arg>\"select $x  from $source where $value \$CONDITIONS\"</arg>
                <arg>--direct</arg>
                <arg>--fetch-size</arg>
                <arg>5000</arg>
                <arg>--delete-target-dir</arg>
                <arg>--target-dir</arg>
                <arg>${target[$j]}</arg>
                <arg>--as-textfile</arg>
                <arg>--relaxed-isolation</arg>
                <arg>--hive-import</arg>
                <arg>--hive-delims-replacement</arg>
                <arg>\"\\\N\"</arg>
                <arg>--hive-overwrite</arg>
                <arg>--hive-table</arg>
                <arg>temp_${hivetable[$j]}</arg>
                <arg>--as-textfile</arg>
                <arg>--create-hive-table</arg>
                <arg>--hive-database</arg>
                <arg>${hivedb[$j]}</arg>
                <arg>--compression-codec</arg>
                <arg>org.apache.hadoop.io.compress.SnappyCodec</arg>


        </sqoop>">>sqoopload_zone2_workflow.xml


fi

echo "Drop table ${hivetable[$j]} PURGE;
CREATE TABLE IF NOT EXISTS ${hivetable[$j]} stored as parquet as Select * from temp_${hivetable[$j]};
Insert into  Hive_Audit select \"${hivedb[$j]}\", \"${hivetable[$j]}\",count(*),from_unixtime(unix_timestamp()) from ${hivetable[$j]}; 
Insert into  sqoop select \"${hivedb[$j]}\", \"${hivetable[$j]}\",count(*),from_unixtime(unix_timestamp()) from ${hivetable[$j]};
drop table temp_${hivetable[$j]} PURGE;">>hive2.hql


	if [[ $(($j+$[$p+1])) -lt $[$n-1] ]];
	then 
		echo "<ok to=\"${hivetable[$(($j+$[$p+1]))]}\"/>
			<error to=\"email-fail\"/>">>sqoopload_zone2_workflow.xml
        else 
      		echo "<ok to=\"join-6d63\"/>
			<error to=\"email-fail\"/>">>sqoopload_zone2_workflow.xml
        fi 
	echo "</action>">>sqoopload_zone2_workflow.xml
        ((j++))
done
echo "Insert overwrite directory '/sqooptmp/count' row format delimited FIELDS TERMINATED BY '\t'  select * from sqoop;">>hive2.hql   
echo "<join name=\"join-6d63\" to=\"hive2\"/>
        <action name=\"hive2\" cred=\"hcat,hive2\">
        <hive2 xmlns=\"uri:oozie:hive2-action:0.1\">
            <job-tracker>\${jobTracker}</job-tracker>
            <name-node>\${nameNode}</name-node>
              <job-xml>>/user/ugsm388/sqoopload_zone_workflow/hive-site.xml</job-xml>
            <jdbc-url>jdbc:hive2://qbda1node04.suntrust.com:10000/default</jdbc-url>
            <script>/user/ugsm388/sqoopload_zone2_workflow/hive2.hql</script>
                </hive2>
        <ok to=\"shell-script\"/>
        <error to=\"email-fail\"/>
    </action>

	<action name=\"shell-script\" cred=\"hive2,hcat\">
        <shell xmlns=\"uri:oozie:shell-action:0.1\">
            <job-tracker>\${jobTracker}</job-tracker>
            <name-node>\${nameNode}</name-node>
            <exec>shell-script.sh</exec>

            <file>/user/ugsm388/sqoopload_zone2_workflow/shell-script.sh#shell-script.sh</file>
              <capture-output/>
        </shell>
        <ok to=\"email-end\"/>
        <error to=\"email-fail\"/>
	</action>

	<action name=\"email-end\">
                <email xmlns=\"uri:oozie:email-action:0.2\">
                        <to>\${email_ids}</to>
                        <subject>Ended| \${wf:name()} - \${wf:id()}</subject>
                        <body> 
workflow Name : \${wf:name()}
workflow Id : \${wf:id()}

Status :  Ended Successfully
Please check the above attachment for sqooped tables and Records

for further detail check at below location :

 \${debug_url}/\${wf:id()}</body>

                        <content_type>text/html</content_type>
			<attachment>/user/ugsm388/Hive_tables.html</attachment>
                </email>

		<ok to=\"End\"/>
		<error to=\"End\"/>
		</action>
	<action name=\"email-fail\">
		<email xmlns=\"uri:oozie:email-action:0.2\">

			<to>\${email_ids}</to>

			<subject>Failed | \${wf:name()} - \${wf:id()}</subject>

			<body>

workflow Id : \${wf:id()} 

Status : Failed Last error action : \${wf:lastErrorNode()} 

Error Message as below : 

\${wf:errorMessage(wf:lastErrorNode())} for further details check at below location : \${debug_url}/\${wf:id()} 

or Run below command from commandline: 

oozie job -oozie \${oozie_url} -info \${wf:id()} 

Tips : Case 1) 

To restart workflow from failed action , execute below command from commandline: oozie job -oozie \${oozie_url} -D oozie.wf.rerun.failnodes=true -rerun \${wf:id()} If issue still persists , Please check for job logs from browser for malicious error/s. 

 </body>

<content_type>text/plain</content_type>

</email>



   <ok to=\"kill\"/>

  <error to=\"kill\"/>

 </action>
 <end name=\"End\"/>
 </workflow-app>">> sqoopload_zone2_workflow.xml
hadoop fs -put hive2.hql /user/ugsm388/sqoopload_zone2_workflow
hadoop fs -put sqoopload_zone2_workflow.xml /user/ugsm388/sqoopload_zone2_workflow
oozie job -oozie http://qbda1node04.suntrust.com:11000/oozie -config job.properties  -run
else

echo "Please copy the Input file to /home/processID/sqoop_load before running the sqoop framework"
fi

