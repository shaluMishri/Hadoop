# import statements
from math import floor
from random import sample
import sys
import numpy as np
import time
import pickle as pk
from pyspark.sql import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import DataType,ArrayType,FloatType,StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import size
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.ml.feature import CountVectorizer
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.mllib.classification import  SVMModel,SVMWithSGD

# gets list of strings from column colname in dataframe df
def get_text(colname,df):

    #changes made
    #select the column exaple 'one' return- list
    rdd = df.select(colname).flatMap(lambda x:[xs.append(u'') if (isinstance(xs,FloatType)) else xs.replace("\n","").replace("\r","").lower() for xs in x ])    
    return rdd
  

# appends strings across row from given columns colnames in dataframe df
def get_multitext(df,*colnames): 
    count = 1 
    for colname in colnames:
        colstrings = get_text(colname,df)
        if count == 0:
            zippedStringsRDD = colstrings.zip(zippedStringsRDD) 
            zippedStringsRDD = zippedStringsRDD.flatMap(lambda x:['*'.join(x)])
        else:
            zippedStringsRDD = colstrings
            count = 0
    return zippedStringsRDD


# gets tuple of strings, dummy blank labels, and complaint ids for analysis from dataframe df
def get_unlabeled_tuple_for_prediction(df):
    stringsList = get_multitext(df,'Client Feedback','Resolution Comments','Analysis Comments')
    blankLabels = []
    for i in range(len(stringsList)):
        blankLabels.append('')
    ids = df.select('Case Number').flatMap(lambda x: x)
    tupleList = zip(stringsList,blankLabels,ids)
    tupleList = [x for x in tupleList if x[0] != '']
    print tupleList
    return tupleList


# returns percentage of correct predictions from lists of correct and incorrect ratings
def average_correct(correct,incorrect):
    return float(sum(correct))/(sum(correct)+sum(incorrect))

# gets include/exclude class labels from column colname in dataframe df
# verbose boolean allows for longer class names (e.g. Include - Auto)
def get_labels(colname,verbose,df):
    if verbose:
      labels = df.select(colname).flatMap(lambda x:[i.append(u'') if (isinstance(i,FloatType)) else i.lower() for i in x])
    else:
      labels = df.select(colname).flatMap(lambda x:[i.append(u'') if (isinstance(i,FloatType)) else i.lower().split(' ',1)[0] for i in x])
  
    return labels

# splits input set into testing and training sets at given proportion
# trainingProp >0 and <1 => training set is trainingProp percent of inputSet
# trainingProp >1 => training set is the decimal portion of trainingProp percent of inputSet, capped at whole number portion
# trainingProp <=0 => training set = testing set = inputSet
def sample_sets(inputSet, trainingProp):
    #numOfElements = len(inputSet)
    numOfElements = inputSet.count()
    if trainingProp < 1.0 and trainingProp > 0.0:
        if numOfElements <= 5:
            trainingSet = inputSet
            testingSet = inputSet
        else:
            trainingLen = int(floor(trainingProp*numOfElements))
            trainingSet = (sample(inputSet,trainingLen))
            testingSet = inputSet - trainingSet
    elif trainingProp > 1.0:
        cap = int(floor(trainingProp))
        prop = trainingProp % 1
        if numOfElements <= 5:
            trainingSet = inputSet
            testingSet = inputSet
        elif numOfElements*prop > cap:
            trainingSet = (sample(inputSet,cap))
            testingSet = inputSet - trainingSet
        else:
            trainingLen = int(floor(prop*numOfElements))
            trainingSet = (sample(inputSet,trainingLen))
            testingSet = inputSet - trainingSet
    else:
        trainingSet = inputSet
        testingSet = inputSet
    print "trainingSet, testingSet------------->"
    print trainingSet.collect(), testingSet.collect()
    return trainingSet, testingSet

# gets tuple of strings, labels, and complaint ids for analysis from dataframe df
def get_labeled_tuple_for_prediction(df):
    stringsList = get_multitext(df,'Client Feedback','Resolution Comments', 'Analysis Comments')
    labels = get_labels('Bucket',False,df)
    ids = df.select('Case Number').flatMap(lambda x: x)
    rdd = labels.map(lambda xs: xs if xs =='ana' or xs =='' else xs.replace(xs,'exclude'))
    #tupleList = zip(stringsList.collect(),rdd.collect(),ids.collect())
    tupleList = stringsList.zip(rdd)    
    #tupleList = zip(stringsList,labels,ids)
    labeledTupleList =tupleList.filter(lambda x:[xs for xs in x if (xs[0] != '' and xs[1] != '')])
    return labeledTupleList

# gets tuple of strings, dummy blank labels, and complaint ids for analysis from dataframe df
def get_unlabeled_tuple_for_prediction(df):
    stringsList = get_multitext(df,'Client Feedback','Resolution Comments', 'Analysis Comments')
    blankLabels = []
    for i in range(len(stringsList)):
        blankLabels.append('')
    ids = df['Case Number']
    tupleList = zip(stringsList,blankLabels,ids)
    tupleList = [x for x in tupleList if x[0] != '']
    
    return tupleList

# prepares data from the sampling stage to the tfidf fitting stage using dataframe df
# ngramMax is the largest ngram size (should use 3)
# min_dof and max_dof are the bounds which an ngram must fit in to be included
# e.g. max_dof = 0.4 excludes ngrams that exist in more than 40% of the population
def data_prep(trainProp,ngramMax,min_dof,max_dof,df):
    # gets list of tuples for analysis
    labeledTupleList = get_labeled_tuple_for_prediction(df)
    # gets sets for cross-validation
    trainList,testList = sample_sets(labeledTupleList,trainProp)
    # breaks tuples apart
    trainText = trainList.map(lambda x : [xs for xs in x])
    testText = testList.map(lambda x: [xs[0] for x in x])
    #trainLabels = trainList.map(lambda x:[xs[1] for xs in x])
    #testLabels = testList.map(lambda x:[xs[1] for xs in x])
    #trainIds = trainList.map(lambda x:[xs[2] for xs in x])
    #testIds = testList.map(lambda x:[xs[2] for xs in x])
    dff = trainText.toDF(['sentence','Bucket'])
    #dff = dff.select(dff.words.cast(ArrayType(StringType())).alias('Words')).collect()
    dff.show()
    trainLabels = dff.select('Bucket').collect()
    # creates and fits countvectorizer based on training set
    #CV = CountVectorizer(ngram_range=(1,ngramMax),min_df=min_dof,max_df=max_dof)
    tokenizer = Tokenizer(inputCol="sentence", outputCol="words")
    wordsData = tokenizer.transform(dff)
    CV = CountVectorizer(inputCol="words", outputCol="rawFeatures",minDF=min_dof)
    trainCounts = CV.fit(wordsData)
    cv_result = trainCounts.transform(wordsData)

    idf = IDF(inputCol="rawFeatures", outputCol="features")
    idfModel = idf.fit(cv_result)
    rescaledData = idfModel.transform(cv_result)
    # creates and fits tfidf based on training set and countvectorizer
    #tfidfTransformer = TfidfTransformer().fit(trainCounts)
    #fitTfidf = tfidfTransformer.transform(trainCounts)
    
    return CV,idfModel,rescaledData,trainList,testList,trainLabels 

# imports data
# df is a dataframe containing the original labeled data
inName = "./ANA/"+sys.argv[-2]
outName = sys.argv[-1]

sc = SparkContext()
sqlContext = SQLContext(sc)
rdd = sc.textFile(inName).map(lambda x: x.split("^"))
df = sqlContext.createDataFrame(rdd,['Case Number','Res_MNTH','Cat Level 5','Client Feedback','Resolution Comments','Analysis Comments','Sales Practice related','Bucket'])
df.show()

# prepares data for model
# used for prediction step
CV,idfModel,rescaledData,trainList,testList,trainLabels  = data_prep(0.0,3,0.01,0.4,df)

# trains classifier
#trainLabels = testList.map(lambda x: [xs[1] for xs in x])
#generalSVCClassifier = SVC(probability=True,kernel='linear').fit(fitTfidf, trainLabels)
generalSVCClassifier =SVMWithSGD.train((rescaledData) ,iterations=10)

# saves model to pickle file for ProdANADetector.py program
outFile = open(outName,'wb')
pk.dump(CV,outFile)
pk.dump(idfModel ,outFile)
pk.dump(rescaledData,outFile)
pk.dump(generalSVCClassifier,outFile)
outFile.close()