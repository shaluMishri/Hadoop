#from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
#from sklearn.svm import SVC
from math import floor
from random import sample
#import pandas as pd
import sys
import numpy as np
import time
import pickle as pk
from pyspark.sql import *
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import Row
from pyspark.sql.types import DataType,FloatType,StringType
from pyspark.sql.functions import *
from pyspark.sql.functions import size
from pyspark.sql import functions as F
from pyspark.sql.functions import col

def f(x): print(x)

# gets list of strings from column colname in dataframe df
def get_text(colname,df):

    #changes made
    #select the column exaple 'one' return- list
    rdd = df.select(colname).flatMap(lambda x:[xs.append(u'') if (isinstance(xs,FloatType)) else xs.replace("\n","").replace("\r","").lower() for xs in x ])    
    print "------->"
    print rdd.collect()
    return rdd.collect()
  

# appends strings across row from given columns colnames in dataframe df
def get_multitext(df,*colnames):
    zippedStrings = []
    for colname in colnames:
        colstrings = get_text(colname,df)
        if len(zippedStrings) != 0:
            zippedStrings = zip(colstrings,zippedStrings)
            zippedStrings = ['*'.join(x) for x in zippedStrings]
        else:
            zippedStrings = colstrings
    print "------------------zippedStrings"
    #print zippedStrings
    return zippedStrings

# gets tuple of strings, dummy blank labels, and complaint ids for analysis from dataframe df
def get_unlabeled_tuple_for_prediction(df):
    stringsList = get_multitext(df,'Client Feedback','Resolution Comments','Analysis Comments')
    blankLabels = []
    print "---range(len(stringsList))"
    #print len(stringsList)
    print "--------range(len(stringsList))"
    #print range(len(stringsList))
    for i in range(len(stringsList)):
        blankLabels.append('')
    ids = df.select('Case Number')
    tupleList = zip(stringsList,blankLabels,ids)
    tupleList = [x for x in tupleList if x[0] != '']
    print tupleList
    return tupleList


#conf = SparkConf().setAppName("Sample-App")
sc = SparkContext()
sqlContext = SQLContext(sc)
#d = sc.parallelize([(["ab c","D$EF","xyZ",12.2],["1.", "2.", "3.", "4."],["hello","hi how ru","hello world","heyy"])]).toDF(["one","two","three"])
#d.show()
#d.printSchema()

# imports data
# df is a dataframe containing the unlabeled testing/evaluation data
# inModel is pickle file containing 4 objects from the ANAModelGenerator.py program
# the objects are CV (a CountVectorizer object), tfidfTransformer, fitTfidf, and generalSVCClassifier (the classifier itself)
inModelName = sys.argv[1]
inSpreadsheetName = sys.argv[2]
outName = sys.argv[3]
print inSpreadsheetName 
rdd =sc.textFile("./ANA/CASE_OUT.csv").map(lambda line:line.split("^"))
df = sqlContext.createDataFrame(rdd,['Case Number','Client Feedback','Resolution Comments','Analysis Comments'])
df.show()

#inModel = open(inModelName,'rb')
#CV = pk.load(inModel)
#tfidfTransformer = pk.load(inModel)
#fitTfidf = pk.load(inModel)
#generalSVCClassifier = pk.load(inModel)
#inModel.close()

# sets threshold parameters
eightTop = 0.8
eightBottom = 0.3
fiftysevenTop = 1
fiftysevenBottom = 0.4
sampleRate = 0.1

# gets data from dataframe for prediction
newTuple = get_unlabeled_tuple_for_prediction(df)

#colString = get_text("one",d)
#col1String=get_multitext(d,"one","two","three")

